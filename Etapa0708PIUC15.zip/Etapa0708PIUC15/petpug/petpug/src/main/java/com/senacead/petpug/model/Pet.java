package com.senacead.petpug.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.util.Date;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "Pet")
public class Pet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "pet_id", nullable = false)
    private Pet pet;

    @ManyToOne
    @JoinColumn(name = "cliente_id", nullable = false)
    private Cliente cliente;

    @Column(name = "data_da_consulta")
    private Date dataDaConsulta;

    @Column(name = "doenca")
    private String doenca;

    @Column(name = "tratamento", nullable = false)
    private String tratamento;

    @Column(name = "valor_total", nullable = false)
    private Double valorTotal;

    @ManyToMany(mappedBy = "produtos")
    private Set<Produto> produtos;

    public void setId(Long id) {
        this.id = id;
    }

    public Set<Pet> getPets() {
        return this.pet == null ? null : this.pet.getConsultas();
    }

    public void addPet(Pet pet) {
        if (this.pet == null) {
            this.pet = pet;
        } else {
            this.pet.getConsultas().add(this);
        }
    }

    public Iterable<Produto> getProdutos() {
        return this.produtos;
    }

    public void addProduto(Produto produto) {
        this.produtos.add(produto);
       
    }

    public Long getId() {
        return id;
    }

    private Set<Pet> getConsultas() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
