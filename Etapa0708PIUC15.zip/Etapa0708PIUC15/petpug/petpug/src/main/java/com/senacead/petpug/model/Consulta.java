
package com.senacead.petpug.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "Consulta")
public class Consulta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "pet_id", nullable = false)
    private Pet pet;

    @ManyToOne
    @JoinColumn(name = "cliente_id", nullable = false)
    private Cliente cliente;

    @Column(name = "data_da_consulta")
    private Date dataDaConsulta;

    @Column(name = "doença")
    private String doenca;

    @Column(name = "tratamento", nullable = false)
    private String tratamento;

    @Column(name = "valor_total", nullable = false)
    private Double valorTotal;

    @ManyToMany(mappedBy = "produtos")
    private Set<Produto> produtos;
    private HashSet<Object> pets;

    public void setId(Long id) {
        this.id = id;
    }

    public Set<Pet> getPets() {
        Set<Pet> pets = null;
        return pets;
    }

    public void addPet(Pet pet) {
        this.pet = pet;
    }

    public Iterable<Produto> getProdutos() {
        return produtos;
    }

    public void addProduto(Produto produto) {
        produtos.add(produto);
        produto.getConsultas().add(this);
    }

    public Long getId() {
        return id;
    }
    public Consulta(Pet pet, Cliente cliente, Date dataDaConsulta, String doenca, String tratamento, Double valorTotal) {
    this.pet = pet;
    this.cliente = cliente;
    this.dataDaConsulta = dataDaConsulta;
    this.doenca = doenca;
    this.tratamento = tratamento;
    this.valorTotal = valorTotal;
    this.pets = new HashSet<>(); // Inicializa pets com um HashSet vazio
}
}